<article>
    <div class="boxcenter">
        <section class="section-tintuc">
                <div class="section-tintuc__hot">
                    <img src="../view/images/tintuc/1.jpg" alt="">
                    <h4><a href="">Waka - Kết quả Chương trình Thử thách đọc sách Tháng 06/2020</a></h4>
                    <p class="xam">21-07-2020 44 lượt xem</p>
                    <p>Cuộc cạnh tranh giữa các bộ truyện Văn học – Linh dị đang vô cùng gay cấn khi Kết hôn âm dương đã cạnh tranh gay gắt cùng Cưng chiều cô vợ quân nhân.</p>
                </div>
                <div class="section-tintuc__hot">
                    <img src="../view/images/tintuc/2.jpg" alt="">
                    <h4><a href="">Waka - Lịch phát hành truyện Văn học tháng 7/2020</a></h4>
                    <p class="xam">30-06-2020 231 lượt xem</p>
                    <p>Trong tháng 7 này, Waka sẽ phát hành hai truyện mới vô cùng hấp dẫn cho các độc giả của Waka VIP!</p>
                </div>
                <div class="section-tintuc__main">
                    <img src="../view/images/tintuc/3.jpg" alt="">
                    <div class="section-tintuc__main-inf">
                        <h4><a href="">HÈ QUÁ CHẤT - ĐỌC PHÁT NGẤT</a></h4>
                        <p class="xam">18-06-2020 775 lượt xem</p>
                        <p>Hè bùng nổ cùng Hiệu Sồi! Chưa bao giờ ngất ngây như thế, double sale tận nóc, truyện sale sẵn sàng toàn chỉ 50 Hạt Sồi/chương và tặng đến 25,000 Hạt Sồi</p>
                    </div>
                </div>
                <div class="section-tintuc__main">
                    <img src="../view/images/tintuc/4.jpg" alt="">
                    <div class="section-tintuc__main-inf">
                        <h4><a href="">Waka - Kết quả Chương trình Thử thách đọc sách Tháng 05/2020</a></h4>
                        <p class="xam">16-06-2020 123 lượt xem</p>
                        <p>Waka hy vọng các Mọt Sách vẫn sẽ luôn dành thời gian ở bên gia đình và cho những đam mê, sở thích của bản thân như những ngày cùng chung tay chống Cô - vít nhé.</p>
                    </div>
                </div>
                <div class="section-tintuc__main">
                    <img src="../view/images/tintuc/5.jpg" alt="">
                    <div class="section-tintuc__main-inf">
                        <h4><a href="">Waka – Thông báo ngừng phát hành ebook Cẩm nang tự học IELTS và Xách ba lô lên và đi</a></h4>
                        <p class="xam">04-06-2020 141 lượt xem</p>
                        <p>Từ ngày 06/06/2020, dựa trên nhu cầu phân phối của nhà xuất bản, hai cuốn sách Cẩm nang tự học IELTS và Xách ba lô lên và đi.</p>
                    </div>
                </div>
                <div class="section-tintuc__main">
                    <img src="../view/images/tintuc/6.jpg" alt="">
                    <div class="section-tintuc__main-inf">
                    <h4><a href="">Waka - Lịch phát hành truyện Văn học tháng 6/2020</a></h4>
                        <p class="xam">31-05-2020 564 lượt xem</p>
                        <p>Trong tháng 6 này Waka sẽ tung ra 4 truyện mới cực hay cho các độc giả của Waka, hãy cùng lót dép hóng nhé!</p>
                    </div>
                </div>
                <div class="section-tintuc__main">
                    <img src="../view/images/tintuc/7.jpg" alt="">
                    <div class="section-tintuc__main-inf">
                        <h4><a href="">NHIỆT CAO SALE HỐT - ĐỒNG SỒI 21</a></h4>
                        <p class="xam">26-05-2020 958 lượt xem</p>
                        <p>Từ ngày 27/05/2020 đến 07/06/2020 chương trình "Nhiệt cao sale hốt - Đồng Sồi 21" sẽ mang đến những ưu đãi bất ngờ cho độc giả</p>
                    </div>
                </div>
                <div class="section-tintuc__main">
                    <img src="../view/images/tintuc/8.jpg" alt="">
                    <div class="section-tintuc__main-inf">
                    <h4><a href="">Waka – Kết quả Chương trình Thử thách đọc sách Tháng 04/2020</a></h4>
                        <p class="xam">15-05-2020 197 lượt xem</p>
                        <p>Hãy cùng Waka xem các Mọt Sách đã tạo nên tháng 4.2020 ấn tượng ra sao nhé!</p>
                    </div>
                </div>
                <div class="section-tintuc__main">
                    <img src="../view/images/tintuc/9.jpg" alt="">
                    <div class="section-tintuc__main-inf">
                        <h4><a href="">HÈ ĐẾN TRUYỆN HAY - ĐỔI NGAY SỒI KHỦNG</a></h4>
                        <p class="xam">13-05-2020 348 lượt xem</p>
                        <p>Hàng loạt truyện mới Hiệu Sồi có khiến bạn háo hức như đứng đống lửa như ngồi đống than. Nghe này "Hè đến truyện hay - Đổi ngay Sồi khủng" còn Hot hơn nhiều</p>
                    </div>
                </div>
                <div class="section-tintuc__main">
                    <img src="../view/images/tintuc/10.jpg" alt="">
                    <div class="section-tintuc__main-inf">
                    <h4><a href="">Waka - Lịch phát hành truyện Văn học tháng 5/2020</a></h4>
                        <p class="xam">30-04-2020 590 lượt xem</p>
                        <p>Trong tháng 5 này sẽ một bộ truyện mới được lên sóng, đó là Quỷ giấu người, bạn biết gì về nghề thợ săn?</p>
                    </div>
                </div>
        </section>
        
    </div>
</article>