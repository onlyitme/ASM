<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - WAKA</title>
    <link rel="stylesheet" href="../view/admin/css/style.css">
</head>

<body>
    <header class="flex-betw">
        <div class="header-logo">
            <a href="admin.php">ADMIN</a>
        </div>
        <div class="header-admin flex-betw">
            <h3 href="">Login</h3>
            <h3 href="">Logout</h3>
        </div>
    </header>
    <main class="flex-betw">
        <aside class="flex-betw">
            <ul>
                <h3>MANAGER</h3>
                <li>
                    <a href="admin.php">HOME</a></li>
                <li>
                    <a href="admin.php?act=qldm">Quản lý danh mục</a>
                </li>
                <li>
                    <a href="admin.php?act=qltg">Quản lý tác giả</a>
                </li>
                <li>
                    <a href="admin.php?act=qlsp">Quản lý sản phẩm</a>
                </li>
            </ul>
            <h4 href="" ><a href="">Logout</a></h4>

        </aside>
        <article>